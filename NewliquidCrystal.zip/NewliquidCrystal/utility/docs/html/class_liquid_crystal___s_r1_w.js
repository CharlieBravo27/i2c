var class_liquid_crystal___s_r1_w =
[
    [ "LiquidCrystal_SR1W", "class_liquid_crystal___s_r1_w.html#a33bff2c123d3dc42a829b0f8034912c9", null ],
    [ "send", "class_liquid_crystal___s_r1_w.html#a7fc0b03977907b4d526a6b9e49a331b1", null ],
    [ "setBacklight", "class_liquid_crystal___s_r1_w.html#a82d844569eb258559afb40ab354eb0a5", null ]
];